# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '37b4c85f23b8184d4adbc7eca8fb342a69b84e14ad59452bd1eb055de8ff0d06ea9eb754042069df71e4127c7313b1ef4ff444c0a3c98abfcce0fc3aa13a3023'